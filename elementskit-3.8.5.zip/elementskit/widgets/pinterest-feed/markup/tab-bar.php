<div class="ekit-feed-items-wrapper--buttons">
    <button class="btn btn-outline-primary btn-pill pinterest-boards-btn">
        <?php esc_html__('Boards', 'elementskit') ?>
    </button>
    <button class="btn btn-outline-secondary btn-pill pinterest-pins-btn">
        <?php esc_html__('Pins', 'elementskit') ?>
    </button>
</div>